# -*- coding: utf-8 -*-


from ReadInput import ReadInpData 
from AsymptoticForcesMoments import GeomStrainParams,AsymptoticForm
from AsymptSystemSol import SystemSolution
from ForceMomentFinalExpression import ResultantantsExpression
from StoreQMatrix import QMatrixFun
from StressStiffFlex import Stressvectors, StiffFlexTensors
from ConstrainingEqs import ConstrainEq
from YieldSurfaces import YiedSurfS12, YiedSurfS11, YiedSurfS22
from YieldEdgePoints import LimitPointsS12, LimitPointsS11, LimitPointsS22
from WriteResults import WriteConstrToFile,  PlotProperties
from BucklingLoads import BucklingLoadComp


filepath = 'InputData_Kagome.txt'
# read the input file for the geometry construction
[DirectionVectors, PeriodicityVectors, NumberOfNodes, OriginBeams,EndBeams, DeltaPerVect1, DeltaPerVect2, AxialStiffness, BendingStiffness, ElemLengths, ElemThick, L1,L2]=ReadInpData(filepath)
# compute the basic 
[P1, P2, TransverseDirVectors, dU1, dU2, dPhi1, dPhi2]=GeomStrainParams(DirectionVectors,PeriodicityVectors,L1,L2)
# compute the asymptotic form of the forces and moments
[NforceDef, TforceDef, MomEndDef, MomOrigDef]=AsymptoticForm(NumberOfNodes, DirectionVectors, TransverseDirVectors, OriginBeams,EndBeams, AxialStiffness, BendingStiffness, DeltaPerVect1, DeltaPerVect2, dU1, dU2, ElemLengths)
# compute the solution of the system of equations
SystemSol=SystemSolution(NumberOfNodes, DirectionVectors, TransverseDirVectors, OriginBeams, EndBeams,NforceDef, TforceDef, MomOrigDef, MomEndDef  )
# compute the final force and moment expression
[NormalForceF, ShearForceF, MomentOrigF, MomentEndF]=ResultantantsExpression(NumberOfNodes, DirectionVectors, TransverseDirVectors, NforceDef, TforceDef, MomEndDef, MomOrigDef, SystemSol )
# compute the Q matrix
Qmatrix=QMatrixFun(DirectionVectors, NormalForceF, ShearForceF, MomentOrigF, MomentEndF)
# compute the stress vectors 
[StressVector1, StressVector2]=Stressvectors(DirectionVectors, TransverseDirVectors, DeltaPerVect1, DeltaPerVect2, NormalForceF, ShearForceF)
# compute the stiffness matrix
[Cmat, Cmat3,FlexMat]=StiffFlexTensors(P1,P2, StressVector1, StressVector2)
# compute the constraining equations
[CompletF,ConstEq]=ConstrainEq(len(DirectionVectors), Qmatrix, FlexMat, ElemThick)

# Compute the Buckling load for normal stress application
[NormalLoadX,NormalLoadY]=BucklingLoadComp(CompletF, AxialStiffness, ElemLengths, ElemThick)

# construct the yield surfaces
Extendned_Limits_S12=YiedSurfS12(ConstEq)
Extendned_Limits_S11=YiedSurfS11(ConstEq)
Extendned_Limits_S22=YiedSurfS22(ConstEq)
# Check which points satisfy all constraints
LimitListS12 = LimitPointsS12(Extendned_Limits_S12, ConstEq)
LImitListS11 = LimitPointsS11(Extendned_Limits_S11, ConstEq)
LimitListS22 = LimitPointsS22(Extendned_Limits_S22, ConstEq)
#plt.plot(S11,EquatBounds[0,:], 'ro', S11,EquatBounds[1,:], 'bo',S11,EquatBounds[2,:], 'go', S11,EquatBounds[3,:], 'ro', S11,EquatBounds[4,:], 'bo',S11,EquatBounds[5,:], 'go' )
#plt.savefig('./Python_Check.png',dpi=400)

# write results to file
WriteConstrToFile(ConstEq)
PlotProperties(LimitListS12,LImitListS11, LimitListS22)
