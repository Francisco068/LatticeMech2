# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 10:25:16 2019

@author: nicka
"""

def ResultantantsExpression(NumberOfNodes, DirectionVectors, TransverseDirVectors, NforceDef, TforceDef, MomEndDef, MomOrigDef, SystemSol ):
    # Collect the final normal, shear and moment expressions
    NormalForceF=[[0] * (4) for i in range(len(TransverseDirVectors))] #du1/dx du1/dy du2/dx du2/dy
    ShearForceF=[[0] * (5) for i in range(len(TransverseDirVectors))] # du1/dx du1/dy du2/dx du2/dy phi
    MomentOrigF=[[0] * (5) for i in range(len(TransverseDirVectors))] # du1/dx du1/dy du2/dx du2/dy phi
    MomentEndF=[[0] * (5) for i in range(len(TransverseDirVectors))] # du1/dx du1/dy du2/dx du2/dy phi
    
    for i in range(len(TransverseDirVectors)):
        # store the normal and the shear force without the unknokns
        for j in range(2*NumberOfNodes,2*NumberOfNodes+4): # store for du1/dx, du1/dy, du2/dx, du2/dy
            NormalForceF[i][j-2*NumberOfNodes]=NforceDef[i][j]
            ShearForceF[i][j-2*NumberOfNodes]=TforceDef[i][j]
            MomentOrigF[i][j-2*NumberOfNodes]=MomOrigDef[i][j]
            MomentEndF[i][j-2*NumberOfNodes]=MomEndDef[i][j]
        for j in range(2,2*NumberOfNodes+NumberOfNodes):
            for k in range(4):
                if j<2*NumberOfNodes:
                   NormalForceF[i][k]=NormalForceF[i][k]+SystemSol[j][k]*NforceDef[i][j]
                   ShearForceF[i][k]=ShearForceF[i][k]+SystemSol[j][k]*TforceDef[i][j]
                   MomentOrigF[i][k]=MomentOrigF[i][k]+SystemSol[j][k]*MomOrigDef[i][j]
                   MomentEndF[i][k]=MomentEndF[i][k]+SystemSol[j][k]*MomEndDef[i][j]
                else:
                   NormalForceF[i][k]=NormalForceF[i][k]+SystemSol[j][k]*NforceDef[i][j+4]
                   ShearForceF[i][k]=ShearForceF[i][k]+SystemSol[j][k]*TforceDef[i][j+4]
                   MomentOrigF[i][k]=MomentOrigF[i][k]+SystemSol[j][k]*MomOrigDef[i][j+4]
                   MomentEndF[i][k]=MomentEndF[i][k]+SystemSol[j][k]*MomEndDef[i][j+4]
    return [NormalForceF, ShearForceF, MomentOrigF, MomentEndF];