# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 15:39:09 2019

@author: nicka
"""

import numpy as np 

def ConstrainEq(NBeams, QMat, FlexMat,ElemThick):
    CompletF=np.zeros((4*NBeams,3))
    QmatArr=np.asarray(QMat)
    CompletF=np.matmul(QmatArr, FlexMat)
    # Now compute the constraining equations usign the Hodge criterion
    ConstEq=np.zeros((4*NBeams,4)) # the number of constraining equations is equal to 4 times the number of cell elements
    # store the first constrain for N/t+4M/t^2<1
    for i in range(NBeams):
        for j in range(3):
           ConstEq[i,j]=ConstEq[i,j]+CompletF[4*i,j]/ElemThick[i]+4*CompletF[4*i+2,j]/(ElemThick[i]*ElemThick[i])
           ConstEq[i,3]=1
    # store the second constraining eq for N/t+4M/t^2>-1 
    k=NBeams-1
    for i in range(NBeams):
        k=k+1
        for j in range(3):
           ConstEq[k,j]=ConstEq[k,j]+CompletF[4*i,j]/ElemThick[i]+4*CompletF[4*i+2,j]/(ElemThick[i]*ElemThick[i])
           ConstEq[k,3]=-1
    # store the third constraining equ for N/t+4M/t^2<1 using the end mom 
    k=2*NBeams-1
    for i in range(NBeams):
        k=k+1
        for j in range(3):
           ConstEq[k,j]=ConstEq[k,j]+CompletF[4*i,j]/ElemThick[i]+4*CompletF[4*i+3,j]/(ElemThick[i]*ElemThick[i])
           ConstEq[k,3]=1
    # store the fourth constraining equ for N/t+4M/t^2>-1 using the end mom 
    k=3*NBeams-1
    for i in range(NBeams):
        k=k+1
        for j in range(3):
           ConstEq[k,j]=ConstEq[k,j]+CompletF[4*i,j]/ElemThick[i]+4*CompletF[4*i+3,j]/(ElemThick[i]*ElemThick[i])
           ConstEq[k,3]=-1
    
    return [CompletF,ConstEq];

