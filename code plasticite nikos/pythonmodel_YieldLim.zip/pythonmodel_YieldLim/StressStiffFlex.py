# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 14:16:59 2019

@author: nicka
"""
import math
import numpy as np 

def Stressvectors(DirectionVectors, TransverseDirVectors, DeltaPerVect1, DeltaPerVect2, NormalForceF, ShearForceF):
        # initialize the stress and moment vectors
    StressVector1=[[0]*(5) for i in range(2)] 
    StressVector2=[[0]*(5) for i in range(2)] 
    
    
    # add to the stress vector based on the normal and shear forces
    for i in range(len(TransverseDirVectors)):
       # add the normal and the shear for du1/dx du1/dy, du2/dx, du2/dy
        for j in range(4):
            StressVector1[0][j]=StressVector1[0][j]+DirectionVectors[i][0]*DeltaPerVect1[i]*NormalForceF[i][j]+TransverseDirVectors[i][0]*DeltaPerVect1[i]*ShearForceF[i][j]
            StressVector1[1][j]=StressVector1[1][j]+DirectionVectors[i][1]*DeltaPerVect1[i]*NormalForceF[i][j]+TransverseDirVectors[i][1]*DeltaPerVect1[i]*ShearForceF[i][j]
            StressVector2[0][j]=StressVector2[0][j]+DirectionVectors[i][0]*DeltaPerVect2[i]*NormalForceF[i][j]+TransverseDirVectors[i][0]*DeltaPerVect2[i]*ShearForceF[i][j]
            StressVector2[1][j]=StressVector2[1][j]+DirectionVectors[i][1]*DeltaPerVect2[i]*NormalForceF[i][j]+TransverseDirVectors[i][1]*DeltaPerVect2[i]*ShearForceF[i][j]
        # add the last part of the rotation
        for j in range(4,5):
            StressVector1[0][j]=StressVector1[0][j]+TransverseDirVectors[i][0]*DeltaPerVect1[i]*ShearForceF[i][j]
            StressVector1[1][j]=StressVector1[1][j]+TransverseDirVectors[i][1]*DeltaPerVect1[i]*ShearForceF[i][j]
            StressVector2[0][j]=StressVector2[0][j]+TransverseDirVectors[i][0]*DeltaPerVect2[i]*ShearForceF[i][j]
            StressVector2[1][j]=StressVector2[1][j]+TransverseDirVectors[i][1]*DeltaPerVect2[i]*ShearForceF[i][j]
    
    return [StressVector1, StressVector2];



def StiffFlexTensors(P1,P2, StressVector1, StressVector2 ):
    # compute the determinant of the transformation matrix
    g=[[0]*(2) for i in range(2)]
    g[0][0]=P1[0]
    g[0][1]=P2[0]
    g[1][0]=P1[1]
    g[1][1]=P2[1]
    Detg=round(np.linalg.det(g),8)
    
    # Compute the derivatives of the position vectors
    dR1=[0]*(2)
    dR2=[0]*(2)
    dR1[0]=P1[0]
    dR1[1]=P1[1]
    dR2[0]=P2[0]
    dR2[1]=P2[1]
    
    # compute the stiffness matrix and the moment matrix
    sigma=[[0]*(2*5) for i in range(2)]
    for i in range(2): # runs over columns
       for j in range(2): # runs over rows
           for k in range(5): # runs over the entries of the stress vector
              sigma[j][i*5+k]=sigma[j][i*5+k]+(1/Detg)*StressVector1[j][k]*dR1[i]
              sigma[j][i*5+k]=sigma[j][i*5+k]+(1/Detg)*StressVector2[j][k]*dR2[i]
              
    # computation of the rigidity matrix 
    Cmat=[[0]*(4) for i in range(4)]
    # loop over the sigma matrix to extract the coefficients (Order: dU1/dx, dU1/dy, dU2/dx, dU2/dy)
    for i in range(4):
        Cmat[0][i]=sigma[0][i]
        Cmat[1][i]=sigma[1][5+i]
        Cmat[2][i]=sigma[0][5+i]
        Cmat[3][i]=sigma[1][i]
   
    # reorder so that dU1/dx, dU2/dy, dU1/dy, dU2/dx 
    dU2dy=[0]*(4)
    dU1dy=[0]*(4)
    dU2dx=[0]*(4)
    for i in range(4):
        dU2dy[i]=Cmat[i][3]
        dU1dy[i]=Cmat[i][1]
        dU2dx[i]=Cmat[i][2]
        Cmat[i][1]=dU2dy[i]
        Cmat[i][2]=dU1dy[i]
        Cmat[i][3]=dU2dx[i]
    #take only the first 3*3 part of the matrix
    Cmat3=[[0]*(3) for i in range(3)]
    for i in range(3):
        for j in range(3):
            Cmat3[i][j]=Cmat[i][j]
    # compute the flexibility matrix taking the inverse
    FlexMat=[[0]*(3) for i in range(3)]
    FlexMat=np.linalg.inv(Cmat3)
    
    return [Cmat, Cmat3,FlexMat] ;
