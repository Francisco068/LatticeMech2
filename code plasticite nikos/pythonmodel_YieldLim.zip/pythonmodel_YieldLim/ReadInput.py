# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 16:37:36 2019

@author: nicka
"""

def func(name, number):
    nam=name+'ss'
    num=number+2
    return [nam, num];

def ReadInpData(FileName):
    DirectionVectors=[]
    PeriodicityVectors=[]
    PeriodicityVectors=[[0] * 2 for i in range(2)]
    OriginBeams=[]
    EndBeams=[]
    DeltaPerVect1=[]
    DeltaPerVect2=[]
    AxialStiffness=[]
    BendingStiffness=[]
    ElemLengths=[]
    ElemThick=[]
    with open(FileName) as fp:
       line = fp.readline()
       cnt = 1
       while line:
           print("Line {}: {}".format(cnt, line.strip()))
           line = fp.readline()
           # Store the number of elements
           if cnt==1:
               NumElements=int(line.split("=")[1])
               print(NumElements)
           # store the director vectors
           if cnt in range(3,3+NumElements):
               DirectVector=line.split("=")[1]
               DirectVector=DirectVector.split("[")[1]
               DirectVector=DirectVector.split("]")[0]
               DirectionVectors.append([0] * 2)
               DirectionVectors[cnt-3][0]=float(DirectVector.split(",")[0])
               DirectionVectors[cnt-3][1]=float(DirectVector.split(",")[1])
               print(DirectVector)
           # store the unit-cell periodicity vectors
           if cnt in range(3+NumElements+1,3+NumElements+3):
               PeriodVect=line.split("=")[1]
               PeriodVect=PeriodVect.split("[")[1]
               PeriodVect=PeriodVect.split("]")[0]
               PeriodicityVectors[cnt-4-NumElements][0]=float(PeriodVect.split(",")[0])
               PeriodicityVectors[cnt-4-NumElements][1]=float(PeriodVect.split(",")[1])
           # Store the number of nodes
           if cnt==3+NumElements+4 and line.split("=")[0]=="NumberNodes": #line.split("=")[0]=='NumberNodes':
               NumberOfNodes=int(line.split("=")[1])
               print(NumberOfNodes)
           # Store the origin beams
           if cnt==3+NumElements+6 and line.split("=")[0]=="Ob":
               OrigBeam=line.split("=")[1]
               OrigBeam=OrigBeam.split("[")[1]
               OrigBeam=OrigBeam.split("]")[0]
               for i in range(NumElements):
                   OriginBeams.append(int(OrigBeam.split(",")[i]))
           # store the end beams
           if cnt==3+NumElements+7 and line.split("=")[0]=="Eb":
               EndBeam=line.split("=")[1]
               EndBeam=EndBeam.split("[")[1]
               EndBeam=EndBeam.split("]")[0]
               for i in range(NumElements):
                   EndBeams.append(int(EndBeam.split(",")[i]))
           if cnt==3+NumElements+8 and line.split("=")[0]=="Delta1":
               Delta=line.split("=")[1]
               Delta=Delta.split("[")[1]
               Delta=Delta.split("]")[0]
               for i in range(NumElements):
                   DeltaPerVect1.append(int(Delta.split(",")[i]))
           if cnt==3+NumElements+9 and line.split("=")[0]=="Delta2":
               Delta=line.split("=")[1]
               Delta=Delta.split("[")[1]
               Delta=Delta.split("]")[0]
               for i in range(NumElements):
                   DeltaPerVect2.append(int(Delta.split(",")[i]))
           if cnt==3+NumElements+11 and line.split("=")[0]=="Ka":
               Stiff=line.split("=")[1]
               Stiff=Stiff.split("[")[1]
               Stiff=Stiff.split("]")[0]
               for i in range(NumElements):
                   AxialStiffness.append(float(Stiff.split(",")[i]))   
           if cnt==3+NumElements+12 and line.split("=")[0]=="Kb":
               Stiff=line.split("=")[1]
               Stiff=Stiff.split("[")[1]
               Stiff=Stiff.split("]")[0]
               for i in range(NumElements):
                   BendingStiffness.append(float(Stiff.split(",")[i])) 
           if cnt==3+NumElements+14 and line.split("=")[0]=="Lb":
               Length=line.split("=")[1]
               Length=Length.split("[")[1]
               Length=Length.split("]")[0]
               for i in range(NumElements):
                   ElemLengths.append(float(Length.split(",")[i]))
           if cnt==3+NumElements+16 and line.split("=")[0]=="tb":
               Length=line.split("=")[1]
               Length=Length.split("[")[1]
               Length=Length.split("]")[0]
               for i in range(NumElements):
                   ElemThick.append(float(Length.split(",")[i]))
           if cnt==3+NumElements+18 and line.split("=")[0]=="L1":
                L1=float(line.split("=")[1])
           if cnt==3+NumElements+19 and line.split("=")[0]=="L2":
                L2=float(line.split("=")[1])
           cnt += 1
    return [DirectionVectors, PeriodicityVectors, NumberOfNodes, OriginBeams,EndBeams, DeltaPerVect1,  DeltaPerVect2, AxialStiffness, BendingStiffness, ElemLengths, ElemThick,  L1,L2];   
  