# -*- coding: utf-8 -*-
"""
Created on Thu Sep 26 09:44:53 2019

@author: nicka
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 16,
        }
SMALL_SIZE = 8
MEDIUM_SIZE = 10
BIGGER_SIZE = 12


def WriteConstrToFile(ConstrMatrix):
  # write Cmatrix to file
  ConMat = pd.DataFrame(ConstrMatrix)
  np.savetxt('./Results/ConMatrix.txt', ConMat, fmt='%10.3f', header='S11,  S22,   S12, Constraint')

def PlotProperties(EdgeListS12,EdgeListS11, EdgeListS22):
    # Plot the yield surface for the Hodge Criterion for the S12=0, S11=0, S22=0
    plt.figure(1)
    plt.fill(EdgeListS12[:,0],EdgeListS12[:,1])
    plt.xlabel('$\sigma_{xx}/\sigma_{yield}$',fontdict=font)
    plt.ylabel('$\sigma_{yy}/\sigma_{yield}$', fontdict=font)
    plt.suptitle('Yeld Surface upon normal loading')
    plt.rc('axes', titlesize=MEDIUM_SIZE)     # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
    plt.savefig('./Results/Yield_NormLoads.png',dpi=400,bbox_inches = "tight")
    plt.close
    # plot the yield dor S11=0
    plt.figure(2)
    plt.fill(EdgeListS11[:,0],EdgeListS11[:,1])
    plt.xlabel('$\sigma_{yy}/\sigma_{yield}$', fontdict=font)
    plt.ylabel('$\sigma_{xy}/\sigma_{yield}$', fontdict=font)
    plt.suptitle('Yeld Surface upon coupled normal-shear loading')
    plt.rc('axes', titlesize=MEDIUM_SIZE)     # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
    plt.savefig('./Results/Yield_NormYShear.png',dpi=400,bbox_inches = "tight")
    plt.close
     # plot the yield dor S11=0
    plt.figure(3)
    plt.fill(EdgeListS22[:,0],EdgeListS22[:,1])
    plt.xlabel('$\sigma_{xx}/\sigma_{yield}$',  fontdict=font)
    plt.ylabel('$\sigma_{xy}/\sigma_{yield}$', fontdict=font)
    plt.suptitle('Yeld Surface upon coupled normal-shear loading')
    plt.rc('axes', titlesize=MEDIUM_SIZE)     # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
    plt.savefig('./Results/Yield_NormXShear.png',dpi=400,bbox_inches = "tight")
    plt.close
  