# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 15:45:07 2019

@author: nicka
"""

import constraint
import numpy as np
import matplotlib.pyplot as plt

problem = constraint.Problem()

problem.addVariable('x', np.linspace(-0.1,0.1,100)) #[1,2,3]
problem.addVariable('y', range(-0.1,0.1,100))

def our_constraint(x, y):
    if 199*x-45*y < 1:
        return True
def our_constraint1(x, y):
    if 0.00001*x+9.8506*y < 1:
        return True
def our_constraint2(x, y):
    if -172*x+52*y < 1:
        return True
def our_constraint3(x, y):
    if y > 0:
        return True
    
problem.addConstraint(our_constraint, ['x','y'])
problem.addConstraint(our_constraint1, ['x','y'])
#problem.addConstraint(our_constraint2, ['x','y'])
#problem.addConstraint(our_constraint3, ['x','y'])

solutions = problem.getSolutions()

# Easier way to print and see all solutions
# for solution in solutions:
#    print(solution)

# Prettier way to print and see all solutions
length = len(solutions)
print("(x,y) ∈ {", end="")
for index, solution in enumerate(solutions):
    if index == length - 1:
        print("({},{})".format(solution['x'], solution['y']), end="")
    else:
        print("({},{}),".format(solution['x'], solution['y']), end="")
print("}")
    
#plt.plot(S11,EquatBounds[0,:], 'ro', S11,EquatBounds[1,:], 'bo',S11,EquatBounds[2,:], 'go', S11,EquatBounds[3,:], 'ro', S11,EquatBounds[4,:], 'bo',S11,EquatBounds[5,:], 'go' )
ListOfPoints=np.zeros((len(solutions),2))
for i in range(len(solutions)):
    Checks=np.array(list(solutions[i].values()))
    ListOfPoints[i,0]=Checks[0]
    ListOfPoints[i,1]=Checks[1]

plt.plot(ListOfPoints[:,0],ListOfPoints[:,1], 'ro')