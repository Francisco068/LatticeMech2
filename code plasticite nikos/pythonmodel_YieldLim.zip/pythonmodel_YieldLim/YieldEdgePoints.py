# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 13:11:09 2019

@author: nicka
"""
import math
import numpy as np

def clockwiseangle_and_distance(point):
    origin = [0, 0]
    refvec = [1, 0]
    # Vector between point and the origin: v = p - o
    vector = [point[0]-origin[0], point[1]-origin[1]]
    # Length of vector: ||v||
    lenvector = math.hypot(vector[0], vector[1])
    # If length is zero there is no angle
    if lenvector == 0:
        return -math.pi, 0
    # Normalize vector: v/||v||
    normalized = [vector[0]/lenvector, vector[1]/lenvector]
    dotprod  = normalized[0]*refvec[0] + normalized[1]*refvec[1]     # x1*x2 + y1*y2
    diffprod = refvec[1]*normalized[0] - refvec[0]*normalized[1]     # x1*y2 - y1*x2
    angle = math.atan2(diffprod, dotprod)
    # Negative angles represent counter-clockwise angles so we need to subtract them 
    # from 2*pi (360 degrees)
    if angle < 0:
        return 2*math.pi+angle, lenvector
    # I return first the angle because that's the primary sorting criterium
    # but if two vectors have the same angle then the shorter distance should come first.
    return angle, lenvector

def LimitPointsS12(CrossPoints, ConstEq):
    NumberPoints=int(np.floor((len(CrossPoints)-1)*len(CrossPoints)/2))
    EdgeListTemp=np.zeros((NumberPoints,2))
    Err=0.00001
    NonZeroCnt=0
    BeamElem=int(len(ConstEq)/4)
    for i in range(len(CrossPoints)):
        Condition_1=False; Condition_2=False; Condition_3=False; Condition_4=False 
        ExcludeZeroNum=(abs(CrossPoints[i,0])>0.000001 or abs(CrossPoints[i,1])>0.000001)
        ka=0 # dummy counter for the control of a single point addition
        for j in range(BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,1]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ka=ka+1
               if ka==BeamElem:
                   Condition_1=True
        la=0
        for j in range(BeamElem,2*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,1]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               la=la+1
               if la==BeamElem:
                   Condition_2=True
        ma=0
        for j in range(2*BeamElem,3*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,1]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ma=ma+1
               if ma==BeamElem:
                   Condition_3=True
        na=0
        for j in range(3*BeamElem,4*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,1]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               na=na+1
               if na==BeamElem:
                   Condition_4=True
        if Condition_1 and Condition_2 and Condition_3 and Condition_4 and ExcludeZeroNum:
               NonZeroCnt=NonZeroCnt+1
               EdgeListTemp[i,0]=CrossPoints[i,0]
               EdgeListTemp[i,1]=CrossPoints[i,1]
    # Store the non-zero points
    EdgeListS12=np.zeros((NonZeroCnt,2)) # store non zero edge points
    InnerCnt=0
    for i in range(NumberPoints):
        if (abs(EdgeListTemp[i,0])>0.000001 or abs(EdgeListTemp[i,1])>0.000001):
           EdgeListS12[InnerCnt,0]=EdgeListTemp[i,0]
           EdgeListS12[InnerCnt,1]=EdgeListTemp[i,1]
           InnerCnt=InnerCnt+1
    ListPoints=sorted(EdgeListS12.tolist(), key=clockwiseangle_and_distance)
    EdgeListS12=np.asarray(ListPoints)
    return EdgeListS12 
    
def LimitPointsS11(CrossPoints, ConstEq):
    NumberPoints=int(np.floor((len(CrossPoints)-1)*len(CrossPoints)/2))
    EdgeListTemp=np.zeros((NumberPoints,2))
    Err=0.0001
    NonZeroCnt=0
    BeamElem=int(len(ConstEq)/4)
    for i in range(len(CrossPoints)):
        Condition_1=False; Condition_2=False; Condition_3=False; Condition_4=False
        ExcludeZeroNum=(abs(CrossPoints[i,0])>0.00000001 or abs(CrossPoints[i,1])>0.00000001)
        ka=0 # dummy counter for the control of a single point addition
        for j in range(BeamElem):
            if (ConstEq[j,1]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ka=ka+1
               if ka==BeamElem:
                   Condition_1=True
        la=0
        for j in range(BeamElem,2*BeamElem):
            if (ConstEq[j,1]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               la=la+1
               if la==BeamElem:
                   Condition_2=True
        ma=0
        for j in range(2*BeamElem,3*BeamElem):
            if (ConstEq[j,1]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ma=ma+1
               if ma==BeamElem:
                   Condition_3=True
        na=0
        for j in range(3*BeamElem,4*BeamElem):
            if (ConstEq[j,1]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               na=na+1
               if na==BeamElem:
                   Condition_4=True
        if Condition_1 and Condition_2 and Condition_3 and Condition_4 and ExcludeZeroNum:
               NonZeroCnt=NonZeroCnt+1
               EdgeListTemp[i,0]=CrossPoints[i,0]
               EdgeListTemp[i,1]=CrossPoints[i,1]
    EdgeListS11=np.zeros((NonZeroCnt,2)) # store non zero edge points
    InnerCnt=0
    for i in range(NumberPoints):
        if (abs(EdgeListTemp[i,0])>0.000001) or (abs(EdgeListTemp[i,1])>0.000001):
           EdgeListS11[InnerCnt,0]=EdgeListTemp[i,0]
           EdgeListS11[InnerCnt,1]=EdgeListTemp[i,1]
           InnerCnt=InnerCnt+1
    ListPoints1=sorted(EdgeListS11.tolist(), key=clockwiseangle_and_distance)
    EdgeListS11=np.asarray(ListPoints1)
    return EdgeListS11    

def LimitPointsS22(CrossPoints, ConstEq):
    NumberPoints=int(np.floor((len(CrossPoints)-1)*len(CrossPoints)/2))
    EdgeListTemp=np.zeros((NumberPoints,2))
    Err=0.0001
    NonZeroCnt=0
    BeamElem=int(len(ConstEq)/4)
    for i in range(len(CrossPoints)):
        Condition_1=False; Condition_2=False; Condition_3=False; Condition_4=False
        ExcludeZeroNum=(abs(CrossPoints[i,0])>0.00000001 or abs(CrossPoints[i,1])>0.00000001)
        ka=0 # dummy counter for the control of a single point addition
        for j in range(BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ka=ka+1
               if ka==BeamElem:
                   Condition_1=True
        la=0
        for j in range(BeamElem,2*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               la=la+1
               if la==BeamElem:
                   Condition_2=True
        ma=0
        for j in range(2*BeamElem,3*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]<=(ConstEq[j,3]+Err)) and ExcludeZeroNum:
               ma=ma+1
               if ma==BeamElem:
                   Condition_3=True
        na=0
        for j in range(3*BeamElem,4*BeamElem):
            if (ConstEq[j,0]*CrossPoints[i,0]+ConstEq[j,2]*CrossPoints[i,1]>=(ConstEq[j,3]-Err)) and ExcludeZeroNum:
               na=na+1
               if na==BeamElem:
                   Condition_4=True
        if Condition_1 and Condition_2 and Condition_3 and Condition_4 and ExcludeZeroNum:
               NonZeroCnt=NonZeroCnt+1
               EdgeListTemp[i,0]=CrossPoints[i,0]
               EdgeListTemp[i,1]=CrossPoints[i,1]
    EdgeListS22=np.zeros((NonZeroCnt,2)) # store non zero edge points
    InnerCnt=0
    for i in range(NumberPoints):
        if abs(EdgeListTemp[i,0])>0.000001 or abs(EdgeListTemp[i,1])>0.000001:
           EdgeListS22[InnerCnt,0]=EdgeListTemp[i,0]
           EdgeListS22[InnerCnt,1]=EdgeListTemp[i,1]
           InnerCnt=InnerCnt+1
    ListPoints2=sorted(EdgeListS22.tolist(), key=clockwiseangle_and_distance)
    EdgeListS22=np.asarray(ListPoints2)
    return EdgeListS22 