# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 12:29:50 2019

@author: nicka
"""

def QMatrixFun(DirectionVectors, NormalForceF, ShearForceF, MomentOrigF, MomentEndF):
    # Collect the final normal, shear and moment expressions
    Qmatrix=[[0] * (3) for i in range(4*len(DirectionVectors))] #du1/dx du1/dy du2/dx du2/dy
    for i in range(len(DirectionVectors)):
        # normal
        Qmatrix[4*i+0][0]=NormalForceF[i][0]
        Qmatrix[4*i+0][1]=NormalForceF[i][3]
        Qmatrix[4*i+0][2]=NormalForceF[i][1]
        # shear
        Qmatrix[4*i+1][0]=ShearForceF[i][0]
        Qmatrix[4*i+1][1]=ShearForceF[i][3]
        Qmatrix[4*i+1][2]=ShearForceF[i][1]
        # moment origin
        Qmatrix[4*i+2][0]=MomentOrigF[i][0]
        Qmatrix[4*i+2][1]=MomentOrigF[i][3]
        Qmatrix[4*i+2][2]=MomentOrigF[i][1]
        # moment end
        Qmatrix[4*i+3][0]=MomentEndF[i][0]
        Qmatrix[4*i+3][1]=MomentEndF[i][3]
        Qmatrix[4*i+3][2]=MomentEndF[i][1]
    return Qmatrix