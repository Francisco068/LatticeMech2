# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 11:15:48 2019

@author: nicka
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 16,
        }
SMALL_SIZE = 8
MEDIUM_SIZE = 10
BIGGER_SIZE = 12

def BucklingLoadComp(CompletF, AxialStiffness, ElemLengths, ElemThick):
    NormalLoadSigmaX=0; NormalLoadSigmaY=0
    CritBeamX=0; CritBeamY=0;
    TcritX=0;  TcritY=0;
    BucklingStressX=0; BucklingStressY=0;
    # compute the number of elements and the max critical load per direction
    NumBeams=int(len(CompletF)/4)
    k=4 # The pilling up of the forces makes them appear every 4 elements
    for i in range(NumBeams):
       # Check for load in the SigmaX direction
       if (abs(CompletF[i*k,0])>NormalLoadSigmaX):  
           NormalLoadSigmaX=CompletF[i*k,0]
           CritBeamX=i
       # Check for load in SigmaY direction
       if (abs(CompletF[i*k,1])>NormalLoadSigmaY):      
           NormalLoadSigmaY=CompletF[i*k,1]
           CritBeamY=i
    # Compute the critical load for each 
    Es=AxialStiffness[0]*ElemLengths[0]/ElemThick[0]
    TcritX=1*np.pi*np.pi*np.power(ElemThick[CritBeamX],3)*Es/12/np.power(ElemLengths[CritBeamX],2)
    TcritY=1*np.pi*np.pi*np.power(ElemThick[CritBeamY],3)*Es/12/np.power(ElemLengths[CritBeamY],2) 
    # Find the element of the maximum normal load per direction
    BucklingStressX=TcritX/NormalLoadSigmaX
    BucklingStressY=TcritY/NormalLoadSigmaY
    # Call the writing routine
    WriteBucklingTofile(BucklingStressX, BucklingStressY)
    PlotBucklingLoadRange(BucklingStressX, BucklingStressY)
    
    return [BucklingStressX, BucklingStressY]


def WriteBucklingTofile(BucklingStressX, BucklingStressY):
  # write Buckling Loads to file
  BucklStresses=np.append(BucklingStressX, BucklingStressY)  
  BucklStress = pd.DataFrame(BucklStresses)
  np.savetxt('./Results/BucklingStress.txt', np.transpose(BucklStress), fmt='%10.3f', header='SigmaX,  SigmaY Buckling ')

def PlotBucklingLoadRange(BucklingStressX, BucklingStressY):
    coeff=np.linspace(0.5,2,50)
    BucklStressX=np.power(coeff,2)*BucklingStressX
    BucklStressY=np.power(coeff,2)*BucklingStressY
    plt.figure(4)
    plt.plot(coeff,BucklStressX, linestyle='solid', linewidth=1.5, color='black',label='$\sigma_{xx}$')
    plt.plot(coeff,BucklStressY, linestyle='dashed', linewidth=1.5, color='red' ,label='$\sigma_{yy}$')
    plt.xlim((0.49, 2.01))
    plt.xlabel('Constraint Factor $n$',fontdict=font)
    plt.ylabel('Buckling Stress', fontdict=font)
    plt.suptitle('Buckling at the unit-cell scale')
    plt.legend(loc="upper left")
    plt.grid(True)
    plt.rc('axes', titlesize=MEDIUM_SIZE)     # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
    plt.savefig('./Results/BucklingStresses.png',dpi=400,bbox_inches = "tight")
    plt.close
    
    return 0
    