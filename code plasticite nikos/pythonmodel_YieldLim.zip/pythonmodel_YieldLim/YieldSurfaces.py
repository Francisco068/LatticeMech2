# -*- coding: utf-8 -*-
"""
Created on Tue Sep 24 15:07:53 2019

@author: nicka
"""
import numpy as np

def YiedSurfS12(ConstEq):
    NumberEquat=int(np.floor((len(ConstEq)-1)*len(ConstEq)/2))
    CrossPointsS12=np.zeros((NumberEquat,2))
    k=0
    for i in range(len(ConstEq)-2):
        for j in range(i+1,len(ConstEq)-1):
            a = np.array([[ConstEq[i,0],ConstEq[i,1]], [ConstEq[j,0],ConstEq[j,1]]])
            b = np.array([ConstEq[i,3],ConstEq[j,3]])
            if abs(np.linalg.det(a))>0:
                x = np.linalg.solve(a, b)
            else:
                x = np.zeros((2,1)) 
            CrossPointsS12[k,:]=np.transpose(x)
            k=k+1
    return CrossPointsS12

def YiedSurfS11(ConstEq):
    NumberEquat=int(np.floor((len(ConstEq)-1)*len(ConstEq)/2))
    CrossPointsS11=np.zeros((NumberEquat,2))
    k=0
    for i in range(len(ConstEq)-2):
        for j in range(i+1,len(ConstEq)-1):
            a = np.array([[ConstEq[i,1],ConstEq[i,2]], [ConstEq[j,1],ConstEq[j,2]]])
            b = np.array([ConstEq[i,3],ConstEq[j,3]])
            if abs(np.linalg.det(a))>0:
                x = np.linalg.solve(a, b)
            else:
                x = np.zeros((2,1)) 
            CrossPointsS11[k,:]=np.transpose(x)
            k=k+1
    return CrossPointsS11

def YiedSurfS22(ConstEq):
    NumberEquat=int(np.floor((len(ConstEq)-1)*len(ConstEq)/2))
    CrossPointsS22=np.zeros((NumberEquat,2))
    k=0
    for i in range(len(ConstEq)-2):
        for j in range(i+1,len(ConstEq)-1):
            a = np.array([[ConstEq[i,0],ConstEq[i,2]], [ConstEq[j,0],ConstEq[j,2]]])
            b = np.array([ConstEq[i,3],ConstEq[j,3]])
            if abs(np.linalg.det(a))>0:
                x = np.linalg.solve(a, b)
            else:
                x = np.zeros((2,1)) 
            CrossPointsS22[k,:]=np.transpose(x)
            k=k+1
    return CrossPointsS22